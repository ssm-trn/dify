class VariableError(ValueError):
    pass
